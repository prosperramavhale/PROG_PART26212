@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo RaceDay Part 2 - restore, build, test, run
echo ============================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET SDK was not found.
  echo Install the .NET 8 SDK and the ASP.NET workload, then try again.
  pause
  exit /b 1
)
echo.
echo Installed SDKs:
dotnet --list-sdks
echo.
echo Restoring packages...
dotnet restore RaceDay.sln
if errorlevel 1 goto failed
echo.
echo Building solution...
dotnet build RaceDay.sln --configuration Release --no-restore
if errorlevel 1 goto failed
echo.
echo Running unit/integration tests...
dotnet test RaceDay.sln --configuration Release --no-build
if errorlevel 1 goto failed
echo.
echo Starting API. On first run it will create/update the SQL Server database.
echo Swagger: https://localhost:7184/swagger
 dotnet run --project RaceDay.API\RaceDay.API.csproj --launch-profile RaceDay.API
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo A step failed. Read the error above. See README.md troubleshooting notes.
pause
exit /b 1
