@echo off
setlocal
cd /d "%~dp0"
dotnet restore RaceDay.sln
if errorlevel 1 goto failed
dotnet build RaceDay.sln --configuration Release --no-restore
if errorlevel 1 goto failed
dotnet test RaceDay.sln --configuration Release --no-build
if errorlevel 1 goto failed
echo All tests passed. Confirm the test summary above before using it as evidence.
pause
exit /b 0
:failed
echo Test/build command failed. Read the error above.
pause
exit /b 1
