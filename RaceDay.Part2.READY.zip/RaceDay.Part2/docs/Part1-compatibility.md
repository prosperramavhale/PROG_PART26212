# Part 1 compatibility notes

The project maps to the six entities in the submitted Part 1 design: Role, User, Event, Category, Enrolment and Result. The original table and column names are retained. The Part 2 brief requires an event type (Run, Walk or Cycle), which was not present in the Part 1 SQL script, so `EventType` is included in the EF model and generated schema.

The Part 1 SQL script drops and recreates the `RaceDay` database. Do not run it on a database with data you want to preserve. Use EF Core migrations for this Code-First implementation.
