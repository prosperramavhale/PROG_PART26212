# RaceDay API demonstration script

Use this as speaking notes while recording the actual running application. Do not claim an endpoint or test worked unless you demonstrate it.

1. **Introduction:** “This is my RaceDay RESTful API for PROG6212 POE Part 2. It uses ASP.NET Core Web API, C#, Entity Framework Core, SQL Server, JWT bearer authentication and xUnit tests.”
2. **Structure:** Show `Controllers`, `Models`, `DTOs`, `Data`, `Services`, `Migrations` and `RaceDay.Tests`.
3. **Database:** Explain Role, User, Event, Category, Enrolment and Result, including the event type added for Run, Walk or Cycle.
4. **Swagger:** Open `/swagger` and point out the authentication, profile, event, category, enrolment and result endpoints.
5. **Participant:** Register a Participant, log in, copy the JWT token and use Authorize. Demonstrate own profile and enrolment endpoints.
6. **Organiser:** Register/log in as an Organiser and demonstrate creating an event and category. Explain that organisers may only manage events they own.
7. **Access control:** Demonstrate a Participant being denied access to organiser-only event creation. Show the HTTP status returned.
8. **Enrolments/results:** Demonstrate enrolment in a published event and show how an Organiser records a result.
9. **Testing:** Run the test suite in Visual Studio or with `dotnet test RaceDay.sln`; show the real result.
10. **CI/CD:** Show the GitHub Actions workflow and its actual successful run.
11. **Conclusion:** Summarise what is implemented and mention any limitations honestly.

After uploading, set the YouTube visibility to **Unlisted**, copy the video link and paste it into the main README.
