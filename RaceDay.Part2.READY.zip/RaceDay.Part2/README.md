# RaceDay RESTful API — PROG6212 POE Part 2

**Technology:** C#, ASP.NET Core Web API (.NET 8), Entity Framework Core, SQL Server, JWT bearer authentication, Swagger/OpenAPI, xUnit, GitHub Actions.

> **Submission honesty note:** This project source and automated workflow are prepared for you. The build and tests must still be run on your computer and in your own GitHub repository. The green Actions screenshot and unlisted YouTube video must be your real results; placeholders are not presented as completed evidence.

## 1. Requirements

- Visual Studio 2022 or compatible newer version with the **ASP.NET and web development** workload.
- .NET 8 SDK.
- SQL Server LocalDB (commonly installed with Visual Studio) or another SQL Server instance.
- A GitHub account for the required repository, commits and Actions workflow.

## 2. Open and run the solution

1. Extract `RaceDay.Part2.VisualStudio.zip`.
2. Open `RaceDay.sln` in Visual Studio.
3. Allow NuGet packages to restore.
4. Open `RaceDay.API/appsettings.json`. The default connection uses LocalDB:
   `Server=(localdb)\MSSQLLocalDB;Database=RaceDay;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true`
   If you use a different SQL Server instance, change the `ConnectionStrings:RaceDay` value.
5. In Solution Explorer, right-click `RaceDay.API` and select **Set as Startup Project**.
6. Select the HTTPS launch profile and press **F5**. On the first launch, the API applies its included EF Core migration automatically and creates the database. Swagger should open in the browser at `/swagger`.

If startup fails with a LocalDB/SQL Server connection error, open **Visual Studio Installer → Modify → Individual components** and install **SQL Server Express LocalDB**, then restart Visual Studio. Alternatively, change `ConnectionStrings:RaceDay` to a SQL Server instance installed on your computer.

The migration creates the six Part 1 tables (`Role`, `User`, `Event`, `Category`, `Enrolment`, `Result`) and seeds the two role names. `EventType` is added to `Event` to satisfy the Part 2 brief (`Run`, `Walk`, `Cycle`). It does not add demo users with fake password hashes. Register an account using the API.

**Warning:** Do not run the original Part 1 SQL script against a database with data you need. It drops and recreates the `RaceDay` database. Use the included EF migration for this project.

## 3. Roles and access rules

- **Organiser:** create, update and cancel their own events; add, update and delete categories for their own events; view enrolments for their own events; update enrolment status; record results for enrolments in their own events.
- **Participant:** view and update their own profile; enrol in published events; view their own enrolments and results.
- **Public:** register, log in, browse events and categories, and view event results.

Role checks use JWT bearer authentication. Passwords are hashed with ASP.NET Core's `PasswordHasher<User>`; plain-text passwords are never stored. Registration accepts only the `Organiser` and `Participant` role names. For a real production system, Organiser accounts should be approved by an administrator rather than allowing unrestricted public self-selection.

### Authenticate in Swagger

1. Call `POST /api/auth/register` with an email, a strong password, first name, last name, optional phone and role.
2. Call `POST /api/auth/login` using the same email and password.
3. Copy the returned `token` value.
4. Click **Authorize** in Swagger and enter `Bearer ` followed by the token. Submit/close the dialog.
5. Try an endpoint allowed for that role. A Participant should receive `403 Forbidden` when trying to create an event; a request without a token to a protected endpoint should receive `401 Unauthorized`.

The JWT key in `appsettings.json` is a development placeholder. Replace it with a strong secret held in local user-secrets or GitHub Actions secrets before any deployment; do not publish production secrets.

## 4. API endpoint reference

| Method | Route | Purpose | Access |
|---|---|---|---|
| POST | `/api/auth/register` | Create an account and hash its password | Public |
| POST | `/api/auth/login` | Verify credentials and return a JWT | Public |
| GET | `/api/users/me` | View own profile | Authenticated |
| PUT | `/api/users/me` | Update own first name, last name and phone | Authenticated |
| GET | `/api/events` | List events | Public |
| GET | `/api/events/{id}` | View an event and its categories | Public |
| POST | `/api/events` | Create an event | Organiser |
| PUT | `/api/events/{id}` | Update own event | Event-owning Organiser |
| DELETE | `/api/events/{id}` | Cancel own event | Event-owning Organiser |
| GET | `/api/events/{eventId}/categories` | List categories for an event | Public |
| POST | `/api/events/{eventId}/categories` | Add a category | Event-owning Organiser |
| PUT | `/api/categories/{id}` | Update a category | Event-owning Organiser |
| DELETE | `/api/categories/{id}` | Delete category without enrolments | Event-owning Organiser |
| POST | `/api/enrolments` | Enrol in a category for a published event | Participant |
| GET | `/api/enrolments/me` | List own enrolments | Participant |
| GET | `/api/events/{eventId}/enrolments` | List enrolments for an owned event | Event-owning Organiser |
| PUT | `/api/enrolments/{id}/status` | Change enrolment status | Event-owning Organiser |
| POST | `/api/results` | Record finish time and position | Event-owning Organiser |
| GET | `/api/events/{eventId}/results` | List event results | Public |
| GET | `/api/results/{id}` | View one result | Public |
| GET | `/api/results/me` | View own results | Participant |

Request bodies are described by the DTO schemas in Swagger. Typical values include event types `Run`, `Walk`, `Cycle`; event statuses `Draft`, `Published`, `Completed`, `Cancelled`; and enrolment statuses `Pending`, `Confirmed`, `Cancelled`, `Completed`.

## 5. Run automated tests

In Visual Studio, right-click `RaceDay.Tests` and select **Run Tests**, or open a terminal in the solution folder and run:

```bash
dotnet restore RaceDay.sln
dotnet build RaceDay.sln --configuration Release
dotnet test RaceDay.sln --configuration Release
```

The integration test suite covers Swagger availability, unauthenticated requests, public event listing, registration and login, duplicate registration, weak passwords, invalid login, role-based event creation, event ownership, and participant enrolment being recorded and visible in the participant's enrolment list. The tests use EF Core's in-memory database and do not require a local SQL Server instance.

If any test fails, fix it and rerun all tests before submission. Do not claim tests pass until you have seen a successful local test result and successful GitHub Actions run.

## 6. GitHub and CI/CD

The workflow is in `.github/workflows/dotnet.yml`. It restores packages, builds the solution and runs tests on pushes and pull requests to `main`, `master` or `part2`.

1. Create your own GitHub repository for the Part 2 work.
2. Push this project to your repository. Do not upload `bin`, `obj`, passwords, tokens or secrets.
3. Open the repository's **Actions** tab and inspect the latest workflow run.
4. Resolve any errors and rerun the workflow until it is green.
5. Take a screenshot of the actual successful run and save it as `docs/images/github-actions-green.png`.
6. Add the screenshot below, commit it and push it.

### Successful CI/CD screenshot

*Submission action required: insert your own screenshot of the successful green GitHub Actions run here after it occurs.*

## 7. YouTube demonstration

*Submission action required: replace the placeholder below with your own unlisted YouTube URL after recording and uploading the demonstration.*

`YouTube demonstration: ADD_UNLISTED_VIDEO_LINK_HERE`

Suggested video order (approximately 5–8 minutes):
1. Introduce RaceDay and show the solution/project structure.
2. Explain the six database entities and the added event type.
3. Run the API and demonstrate the Swagger page.
4. Register and log in as a Participant; show the token and own profile/enrolments.
5. Log in as an Organiser; create an event/category and explain ownership checks.
6. Show enrolment and results endpoints.
7. Run the unit tests and show the test results.
8. Open GitHub Actions and explain the automated build-and-test workflow.

## 8. Meaningful commit checklist

The assignment requires at least 20 meaningful commits from your own account. Make commits as you implement, test and document the work; do not fabricate or backdate commits. A possible sequence is:

1. Add ASP.NET Core Web API solution.
2. Add EF Core SQL Server dependencies.
3. Add role and user entities.
4. Add event entity and event type.
5. Add category entity and constraints.
6. Add enrolment entity and uniqueness rule.
7. Add result entity and uniqueness rule.
8. Configure the EF Core context.
9. Add the initial database migration.
10. Add registration DTO validation.
11. Implement secure registration and password hashing.
12. Implement login and JWT token service.
13. Add own-profile endpoints.
14. Add public event browsing endpoints.
15. Add organiser event management and ownership checks.
16. Add event category endpoints.
17. Add participant enrolment endpoints.
18. Add organiser enrolment status endpoint.
19. Add results endpoints and validation.
20. Add Swagger descriptions and bearer authentication.
21. Add authentication and role-access tests.
22. Add enrolment integration tests.
23. Configure GitHub Actions.
24. Document setup and endpoint behaviour.
25. Add the real CI screenshot and video link.

Only commit changes that you have actually made. The list is a guide, not a claim that those commits already exist.

## 9. Part 1 compatibility

The project preserves the six tables and core relationships in Section A and Section C. The API endpoint paths follow the Section B plan. `EventType` is an additional required property because Part 2 explicitly requires each event to be a run, walk or cycle. The database is created from the EF Core Code-First migration included in this project.
